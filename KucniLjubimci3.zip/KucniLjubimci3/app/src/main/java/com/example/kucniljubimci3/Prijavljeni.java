package com.example.kucniljubimci3;

public class Prijavljeni {

    int id;
    String imePrezime;
    String maticniBroj;

    public Prijavljeni() {
    }

    public Prijavljeni(String imePrezime, String maticniBroj) {
        this.imePrezime = imePrezime;
        this.maticniBroj = maticniBroj;
    }

    public Prijavljeni(int id, String imePrezime, String maticniBroj) {
        this.id = id;
        this.imePrezime = imePrezime;
        this.maticniBroj = maticniBroj;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getImePrezime() {
        return imePrezime;
    }

    public void setImePrezime(String imePrezime) {
        this.imePrezime = imePrezime;
    }

    public String getMaticniBroj() {
        return maticniBroj;
    }

    public void setMaticniBroj(String maticniBroj) {
        this.maticniBroj = maticniBroj;
    }

    @Override
    public String toString() {
        return imePrezime +", maticni broj:" + maticniBroj + "\n";
    }
}
