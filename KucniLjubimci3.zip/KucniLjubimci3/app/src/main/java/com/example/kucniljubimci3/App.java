package com.example.kucniljubimci3;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.graphics.Color;
import android.os.Build;

public class App extends Application {
    public static final String CHANEL_1_ID="CHANEL_1";
    public static final String CHANEL_2_ID="CHANEL_2";
    public static final String CHANEL_3_ID="CHANEL_2";
    @Override
    public void onCreate() {
        super.onCreate();

        kreirajKanale();
    }
    public void kreirajKanale(){
        if(Build.VERSION.SDK_INT>= Build.VERSION_CODES.O) {
            NotificationChannel chanel = new NotificationChannel(CHANEL_1_ID, "chane1", NotificationManager.IMPORTANCE_HIGH);
            chanel.enableLights(true);
            chanel.setLightColor(Color.RED);
            chanel.enableVibration(true);
            chanel.setDescription("Neuspesan unos prijavljenog. Pokusajte opet!");

            NotificationChannel chanel2 = new NotificationChannel(CHANEL_2_ID, "chanel2", NotificationManager.IMPORTANCE_LOW);

            chanel.setDescription("Uspesno ste uneli podatke o prijavljenima");

            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(chanel);
            manager.createNotificationChannel(chanel2);
        }
    }
}
