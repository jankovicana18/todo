package com.example.kucniljubimci3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Notification;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText imePrezimeEditText, maticniBrojEditText, maticniBrojEditText2;
    TextView prijavljeniTextView;
    NotificationManagerCompat notificationManagerCompat;


    MySQLiteHelper db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imePrezimeEditText = findViewById(R.id.imePrezimeEditText);
        maticniBrojEditText = findViewById(R.id.maticniBrojEditText);
        prijavljeniTextView = findViewById(R.id.prijavljeniTextView);
        maticniBrojEditText2 = findViewById(R.id.maticniBrojEditText2);
        notificationManagerCompat = NotificationManagerCompat.from(this);

        db = new MySQLiteHelper(this);

        prikaziSvePrijavljene();
    }



    public void posaljiPriBrisanjuSvih(View view) {

        Notification notification = new NotificationCompat.Builder(this, App.CHANEL_1_ID)
                .setStyle( new NotificationCompat.BigTextStyle().bigText("Uspesnpo ste obrisali sve prijavljene.").setBigContentTitle("USPESNO").setSummaryText("Ovo je summaryText"))
                .setSmallIcon(R.drawable.greska)
                .build();
        notificationManagerCompat.notify(1, notification);
    }

    public void posaljiPriBrisanju(View view) {
        if(maticniBrojEditText2.getText().toString().trim().isEmpty()){
            Notification notification = new NotificationCompat.Builder(this, App.CHANEL_2_ID)
                    .setStyle( new NotificationCompat.BigTextStyle().bigText("Neuspesno brisanje. Morate uneti maticni broj!").setBigContentTitle("NEUSPESNO").setSummaryText("Ovo je summaryText"))
                    .setSmallIcon(R.drawable.greska)
                    .build();
            notificationManagerCompat.notify(1, notification);
        }else {
            Notification notification = new NotificationCompat.Builder(this, App.CHANEL_2_ID)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText("Uspesnpo ste obrisali jednog prijavljenog.").setBigContentTitle("USPESNO").setSummaryText("Ovo je summaryText"))
                    .setSmallIcon(R.drawable.greska)
                    .build();
            notificationManagerCompat.notify(1, notification);
        }
    }
    public void posaljiPriDodavanju(View view) {
        if(maticniBrojEditText.getText().toString().length() < 13){
            Notification notification = new NotificationCompat.Builder(this, App.CHANEL_3_ID)
                    .setStyle( new NotificationCompat.BigTextStyle().bigText("Neuspesno dodavanje. Maticni broj mora imati 13 cifara!").setBigContentTitle("NEUSPESNO").setSummaryText("Ovo je summaryText"))
                    .setSmallIcon(R.drawable.greska)
                    .build();
            notificationManagerCompat.notify(1, notification);
        }else {
            Notification notification = new NotificationCompat.Builder(this, App.CHANEL_3_ID)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText("Uspesnpo ste dodali jednog prijavljenog.").setBigContentTitle("USPESNO").setSummaryText("Ovo je summaryText"))
                    .setSmallIcon(R.drawable.greska)
                    .build();
            notificationManagerCompat.notify(1, notification);
        }
    }
    public void dodajPrijavljenog(View view) {
        String imePrezime = String.valueOf(imePrezimeEditText.getText());
        String maticniBroj = String.valueOf(maticniBrojEditText.getText());

        if(maticniBrojEditText.getText().toString().length() == 13) {
            db.dodajStudenta(new Prijavljeni(imePrezime, maticniBroj));
        }

        prikaziSvePrijavljene();
        posaljiPriDodavanju(view);
    }

    public void obrisiPrijavljenog(View view) {
        String maticniBRoj = String.valueOf(maticniBrojEditText2.getText());

        db.deletePrijavljenog(maticniBRoj);

        prikaziSvePrijavljene();
        posaljiPriBrisanju(view);
    }

    public void obrisiSvePrijavljene(View view){
        db.deleteAll();

        prikaziSvePrijavljene();
       posaljiPriBrisanjuSvih(view);
    }


    private void prikaziSvePrijavljene() {
        prijavljeniTextView.setText("");
        List<Prijavljeni> list = db.dajSvePrijavljene();
        for (Prijavljeni prijavljeni : list) {
            prijavljeniTextView.append(prijavljeni.toString());
        }
    }
}
