package com.example.kucniljubimci3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.LinkedList;
import java.util.List;

public class MySQLiteHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "prijavljeniDB.db";
    private static final int DB_VERSION = 1;

    public MySQLiteHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE prijavljeni ( " +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "imePrezime TEXT, "+
                "maticniBroj TEXT )";


        db.execSQL(sql);
    }
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS prijavljeni");

        this.onCreate(db);
    }
    public void dodajStudenta(Prijavljeni prijavljeni){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("imePrezime", prijavljeni.getImePrezime());
        values.put("maticniBroj", prijavljeni.getMaticniBroj());

        db.insert("prijavljeni", null, values);

        db.close();
    }
    public Prijavljeni dajPrijavljenog(int id){


        SQLiteDatabase db = this.getReadableDatabase();
        String[] COLUMNS = {"id", "imePrezime", "maticniBroj"};

        Cursor cursor =
                db.query("prijavljeni", COLUMNS, " id = ?", new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();

        Prijavljeni prijavljeni = new Prijavljeni();
        prijavljeni.setId(cursor.getInt(0));
        prijavljeni.setImePrezime(cursor.getString(1));
        prijavljeni.setMaticniBroj(cursor.getString(2));


        return prijavljeni;
    }


    public List<Prijavljeni> dajSvePrijavljene() {
        List<Prijavljeni> prijavljeni = new LinkedList<Prijavljeni>();

        String query = "SELECT  * FROM prijavljeni";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        Prijavljeni prijavljen = null;

        while (cursor.moveToNext()) {
            prijavljen = new Prijavljeni ();
            prijavljen.setId(cursor.getInt(0));
            prijavljen.setImePrezime(cursor.getString(1));
            prijavljen.setMaticniBroj(cursor.getString(2));


            prijavljeni.add(prijavljen);
        }

        return prijavljeni;
    }
    public int updatePrijavljenog(Prijavljeni prijavljeni) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("maticniBroj", prijavljeni.getMaticniBroj());
        values.put("imePrezime", prijavljeni.getImePrezime());
        int i = db.update("prijavljeni",
                values,
                "id = ?",
                new String[] { String.valueOf(prijavljeni.getId()) });
        db.close();

        return i;
    }

    public void deletePrijavljenog(String maticniBroj) {
        SQLiteDatabase db = this.getWritableDatabase();

        String upit = "DELETE FROM prijavljeni WHERE maticniBroj='" + maticniBroj + "'";
        db.execSQL(upit);
        db.close();
    }

    public void deletePrijavljenog2(Prijavljeni prijavljeni) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete("prijavljeni", "id = ?", new String[] { String.valueOf(prijavljeni.getId()) });
        db.close();
    }

    public void deleteAll() {
        SQLiteDatabase db = this.getWritableDatabase();

        String upit = "DELETE FROM prijavljeni";
        db.execSQL(upit);
        db.close();
    }
}